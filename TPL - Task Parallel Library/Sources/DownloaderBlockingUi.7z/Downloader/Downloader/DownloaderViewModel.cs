﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel;
using System.Windows.Input;
using Microsoft.Win32;

// http://www.helvetic-heli.ch/wp-content/uploads/2012/08/MG_5646.jpg
namespace Downloader
{
    class DownloaderViewModel : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;

        private string url;
        public string Url
        {
            get { return url; }
            set { url = value; PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Url))); }
        }
        private string filename;
        public string Filename
        {
            get { return filename; }
            set { filename = value; PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Filename))); }
        }
        private string loadedFile;
        public string LoadedFile
        {
            get { return loadedFile; }
            set { loadedFile = value; PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(LoadedFile))); }
        }

        public ICommand FileSaveCommand
        {
            get
            {
                return new RelayCommand(o => {
                    SaveFileDialog saveFileDialog = new SaveFileDialog();
                    if (saveFileDialog.ShowDialog() == true)
                    {
                        Filename = saveFileDialog.FileName;
                    }
                });
            }
        }

        public ICommand DownloadCommand
        {
            get
            {
                return new RelayCommand(o =>
                {
                    WebDownloader wd = new WebDownloader();
                    wd.Download(Url, Filename);
                    LoadedFile = Filename;
                });
            }
        }


    }
}

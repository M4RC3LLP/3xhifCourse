﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace Downloader
{
    class WebDownloader
    {
        public double Download(string url, string filename)
        {
            DateTime start = DateTime.Now;

            WebClient wc = new WebClient();
            wc.DownloadFile(url, filename);
            DateTime end = DateTime.Now;

            /* Wie groß ist die heruntergeladene Datenmenge? */
            long len = new System.IO.FileInfo(filename).Length;
            /* Wert in MBit/s zurückgeben */
            return len / 1000000.0 * 8.0 / (end - start).TotalSeconds;
        }
    }
}

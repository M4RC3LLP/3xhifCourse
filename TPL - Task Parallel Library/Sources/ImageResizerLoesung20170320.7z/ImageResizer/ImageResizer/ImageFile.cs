﻿using System;
using System.IO;
using System.Windows.Media.Imaging;
using System.Windows.Media;

namespace ImageResizer
{
    /// <summary>
    /// Bildbearbeitungsklasse für das Skalieren des Bildes.
    /// </summary>
    /// <example>
    /// ImageFile imageFile = new ImageFile() { SourceFile = new FileInfo(@"C:\Bilder\meinBild.jpg") };
    /// imageFile.Width = Width;
    /// imageFile.Height = Height;
    /// imageFile.Quality = 80;
    /// imageFile.Resize();
    /// </example>
    class ImageFile
    {
        /// <summary>
        /// Die Breite des skalierten Bildes.
        /// </summary>
        public int Width { get; set; }
        /// <summary>
        /// Die Höhe des skalierten Bildes.
        /// </summary>
        public int Height { get; set; }
        /// <summary>
        /// Die JPEG Qualität (1 bis 100)
        /// </summary>
        public int Quality { get; set; } = 80;
        /// <summary>
        /// Die Dateiinfo des Originalbildes.
        /// </summary>
        public FileInfo SourceFile { get; set; }
        /// <summary>
        /// Die Dateiinfo des skalierten Bildes. Hier wird an den Dateinamen _600px angehängt, wenn
        /// das Bild auf 600 Pixel breite skaliert werden soll.
        /// </summary>
        public FileInfo ResizedFile
        {
            get
            {
                return new FileInfo(SourceFile.FullName.Replace(SourceFile.Extension, "_" + Width + "px" + SourceFile.Extension));
            }
        }
        /// <summary>
        /// Führt die skalierung durch.
        /// </summary>
        /// <returns>true, wenn das Bild skaliert werden konnte. false bei Fehlern.</returns>
        public bool Resize()
        {
            bool success = true;
            try
            {
                /* Datei erstellen bzw, überschreiben, wenn sie schon existiert. */
                using (FileStream fs = new FileStream(ResizedFile.FullName, FileMode.Create))
                {
                    try
                    {
                        BitmapFrame source = BitmapFrame.Create(new Uri(SourceFile.FullName));
                        /* Das Bild proportional skalieren. */
                        double scaleFactor = Math.Min(1.0 * Width / source.PixelWidth, 1.0 * Height / source.PixelHeight);
                        TransformedBitmap tb = new TransformedBitmap(
                            source,
                            new ScaleTransform(scaleFactor, scaleFactor)
                        );
                        JpegBitmapEncoder encoder = new JpegBitmapEncoder();
                        encoder.QualityLevel = Quality;
                        encoder.Frames.Add(BitmapFrame.Create(tb));
                        encoder.Save(fs);
                    }
                    catch
                    {
                        success = false;
                    }
                }
            }
            catch
            {
                /* Bei Filesystem Fehlern (kein Zugriff möglich, keine Rechte, etc.) */
                success = false;
            }
            return success;
        }

    }
}

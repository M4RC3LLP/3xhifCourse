﻿/*
 * Benötigt eine Referenz auf System.Windows.Forms, sie muss mit References -> Add Reference hinzugefügt
 * werden. Den "Ordner suchen" Dialog gibt's nur dort.
 * 
 * Außerdem ist unter Build -> Configuration Manager bei Active Solution Platform mit <New...> die
 * x64 Architektur auszuwählen. Sonst gibt es bei einer 32bit App eine MemoryException wenn die
 * Bilder viel und groß sind.
 */
using System;
using System.Collections.Generic;
using System.ComponentModel;       // Für INotifyPropertyChanged
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Input;        // Für ICommand
using System.IO;                   // Für die DirectoryInfo
using System.Windows;

namespace ImageResizer
{
    /// <summary>
    /// ViewModel für das ImageResize Tool. Nicht vergessen im MainWindow Konstruktor den 
    /// DataContext darauf zu setzen!
    /// </summary>
    class ImageResizerViewModel : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;
        private string folder;

        /// <summary>
        /// Binding Property für das Textfeld mit dem Fotopfad.
        /// </summary>
        public string Folder
        {
            get
            {
                return folder;
            }
            set
            {
                folder = value;
                ImageFiles = getImageFiles(new string[] { ".jpg", ".jpeg" });
                ProcessedImages = 0;
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Folder)));
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(ImageFiles)));
                /* Die Bildanzahl für die Progressbar setzen. */
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(ImageCount)));
            }
        }

        /// <summary>
        /// Binding für das Textfeld mit der Bildbreite.
        /// </summary>
        public int Width { get; set; }
        /// <summary>
        /// Binding für das Textfeld mit der Bildhöhe.
        /// </summary>
        public int Height { get; set; }

        /// <summary>
        /// Binding für den Max Value der Progressbar.
        /// </summary>
        public int ImageCount
        {
            get
            {
                return ImageFiles == null ? 0 : ImageFiles.Count();
            }
        }
        private int processedImages;
        /// <summary>
        /// Binding für den aktuellen Stand der Progressbar.
        /// </summary>
        public int ProcessedImages
        {
            get
            {
                return processedImages;
            }
            set
            {
                processedImages = value;
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(ProcessedImages)));
            }
        }

        /// <summary>
        /// Binding für den Suchbutton. Hier wird der klassiche Windows Forms Ordner suchen 
        /// Dialog geöffnet und das Ergebnis in Folder geschrieben.
        /// </summary>
        public ICommand SearchCommand
        {
            get
            {
                return new RelayCommand(o =>
                {
                    using (System.Windows.Forms.FolderBrowserDialog dialog =
                        new System.Windows.Forms.FolderBrowserDialog())
                    {
                        System.Windows.Forms.DialogResult result = dialog.ShowDialog();
                        if (result == System.Windows.Forms.DialogResult.OK)
                        {
                            Folder = dialog.SelectedPath;
                        }
                    }
                });
            }
        }

        /// <summary>
        /// Binding für den Startbutton ohne TPL (einfach mit der foreach Schleife alle Dateien 
        /// nacheinander abarbeiten)
        /// </summary>
        public ICommand StartSingleCommand
        {
            get
            {
                return new RelayCommand(o =>
                {
                    if (ImageFiles == null) { return; }
                    DateTime start = DateTime.Now;
                    ProcessedImages = 0;
                    foreach (FileInfo image in ImageFiles)
                    {
                        ImageFile imageFile = new ImageFile() { SourceFile = image };
                        imageFile.Width = Width;
                        imageFile.Height = Height;
                        imageFile.Quality = 80;
                        imageFile.Resize();
                        ProcessedImages++;
                    }
                    MessageBox.Show((DateTime.Now - start).TotalSeconds + " s");
                });
            }
        }

        /// <summary>
        /// Binding für den Startbutton mit TPL. Hier wird mit Parallel.ForEach die Liste der
        /// Bilddateien durchgegangen und mit Tasks die Skalierung durchgeführt.
        /// </summary>
        public ICommand StartTplCommand
        {
            get
            {
                return new RelayCommand(o =>
                {
                    /* ForEach ist bei null heikel. */
                    if (ImageFiles == null) { return;  }
                    DateTime start = DateTime.Now;
                    ProcessedImages = 0;
                    Parallel.ForEach(ImageFiles, image =>
                    {
                        ImageFile imageFile = new ImageFile() { SourceFile = image };
                        imageFile.Width = Width;
                        imageFile.Height = Height;
                        imageFile.Quality = 80;
                        imageFile.Resize();
                        ProcessedImages++;
                    });
                    MessageBox.Show((DateTime.Now - start).TotalSeconds + " s");
                });
            }
        }

        /// <summary>
        /// Binding für die Listbox, die die gefundenen Dateien anzeigt.
        /// </summary>
        public IEnumerable<FileInfo> ImageFiles { get; set; }

        /// <summary>
        /// Liefert alle Dateien eines Ordners, die der Übergebenen Liste von Erweiterungen entsprechen.
        /// </summary>
        /// <param name="extensions">Array mit den Erweiterungen. Diese müssen mit . beginnen.</param>
        /// <returns>Liste aller gefundenen Dateien oder null im Fehlerfall.</returns>
        /// <example>
        /// ImageFiles = getImageFiles(new string[] { ".jpg", ".jpeg" })
        /// </example>
        private IEnumerable<FileInfo> getImageFiles(string[] extensions)
        {
            try
            {
                DirectoryInfo di = new DirectoryInfo(Folder);
                return di.EnumerateFiles().Where(fi => extensions.Any(e => e == fi.Extension));
            }
            catch
            {
                return null;
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel;
using System.Windows.Input;
using Microsoft.Win32;

/* Demo URL (7.4 MB großes Bild):
 * http://www.helvetic-heli.ch/wp-content/uploads/2012/08/MG_5646.jpg */
namespace Downloader
{
    class DownloaderViewModel : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;

        private string url;
        /// <summary>
        /// Binding für das Textfeld mit der URL.
        /// </summary>
        public string Url
        {
            get { return url; }
            set { url = value; PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Url))); }
        }
        private string filename;
        /// <summary>
        /// Binding für das Feld mit dem Dateinamen.
        /// </summary>
        public string Filename
        {
            get { return filename; }
            set { filename = value; PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Filename))); }
        }

        private string loadedFile;
        /// <summary>
        /// Binding für die Quelle des Image Controls.
        /// </summary>
        public string LoadedFile
        {
            get { return loadedFile; }
            set { loadedFile = value; PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(LoadedFile))); }
        }

        /// <summary>
        /// Damit der Button während dem herunterladen deaktiviert wird.
        /// </summary>
        bool downloadInProgress = false;
        public bool DownloadInProgress
        {
            get { return downloadInProgress; }
            set
            {
                downloadInProgress = value;
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(
                    nameof(DownloadCommand)));
            }
        }
        /// <summary>
        /// Binding für den FileSave Button.
        /// Öffnet den Standard Speichern unter... Dialog und schreibt den gewählten Dateinamen
        /// in das Feld Filename.
        /// </summary>
        public ICommand FileSaveCommand
        {
            get
            {
                return new RelayCommand(o =>
                {
                    SaveFileDialog saveFileDialog = new SaveFileDialog();
                    if (saveFileDialog.ShowDialog() == true)
                    {
                        Filename = saveFileDialog.FileName;
                    }
                });
            }
        }

        /// <summary>
        /// Binding für den Button Download.
        /// Lädt die angegebene URL in die angegebene Datei. Während des Ladens wird der
        /// Download Button deaktiviert.
        /// </summary>
        public ICommand DownloadCommand
        {
            get
            {
                return new RelayCommand(o =>
                {
                    WebDownloader wd = new WebDownloader();
                    /* Event, wenn der Download fertig ist: es wird der Button wieder freigegeben
                     * und LoadedFile gesetzt, sodass das Bild angezeigt wird. */
                    wd.OnReady += ((sender, args) =>
                    {
                        DownloadInProgress = false;
                        LoadedFile = Filename;
                    });

                    DownloadInProgress = true;
                    /* Wir definieren den Task. Er wird aber noch nicht gestartet! */
                    Task t = new Task(() =>
                    {
                        wd.Download(Url, Filename);
                    });
                    /* t.Wait() führt zu einem einfrieden des UI --> wir müssen also im Event
                     * OnReady des WebDownloaders unser Programm fortsetzen
                       t.Wait(); */

                    /*  Den Task starten. Das Programm geht sofort weiter, obwohl das Bild noch 
                     *  nicht  geladen wurde. */
                    t.Start();
                },
                    /* Lambda Expression, die angibt, wann der Button aktiviert ist. Entspricht Func<object, bool>
                     * Aktiviert den Button nur, wenn kein Download läuft. */
                    o => !downloadInProgress
                );
            }
        }
    }
}

﻿using System;
using System.Net;

namespace Downloader
{
    /// <summary>
    /// Stellt Download Methoden bereit, die eine URL in eine Datei laden.
    /// </summary>
    class WebDownloader
    {
        /// <summary>
        /// Gemessene Bitrate des Downloads in Mbit/s
        /// </summary>
        public double Bitrate { private get; set; }
        /// <summary>
        /// Der Eventhandler muss den Aufbau void function(object sender, EventArgs e) haben.
        /// Deshalb wird ein generischer Delegate vom Typ Func<object, EventArgs> verwendet.
        /// </summary>
        public event Action<object, EventArgs> OnReady;
        /// <summary>
        /// Lädt eine URL in die angegebene Datei und befüllt das Property Bitrate.
        /// </summary>
        /// <param name="url">Die URL (http://....)</param>
        /// <param name="filename">Der Dateiname mit oder ohne Pfad.</param>
        /// <returns>true, wenn die Datei geladen wurde. False wenn ein Fehler auftrat.</returns>
        public bool Download(string url, string filename)
        {
            try
            {
                DateTime start = DateTime.Now;

                WebClient wc = new WebClient();
                wc.DownloadFile(url, filename);
                DateTime end = DateTime.Now;

                /* Wie groß ist die heruntergeladene Datenmenge? */
                long len = new System.IO.FileInfo(filename).Length;
                /* Wert in MBit/s zurückgeben */
                Bitrate = len / 1000000.0 * 8.0 / (end - start).TotalSeconds;
                OnReady?.Invoke(this, null);
                return true;
            }
            catch
            {
                return false;
            }
        }
    }
}
